package sit.int202.accountproject.models;


import java.time.LocalDate;

public class Transaction {
    static int count = 0 ;
    private int id ;
    private LocalDate tranDate ;
    private String tranType ;
    double amount ;
    String note ;

    public Transaction(LocalDate tranDate, String tranType, double amount, String note) {
        this.id = ++count ;
        this.tranDate = tranDate;
        this.tranType = tranType;
        this.amount = amount;
        this.note = note;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDate getTranDate() {
        return tranDate;
    }

    public void setTranDate(LocalDate tranDate) {
        this.tranDate = tranDate;
    }

    public String getTranType() {
        return tranType;
    }

    public void setTranType(String tranType) {
        this.tranType = tranType;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "id=" + id +
                ", tranDate=" + tranDate +
                ", tranType='" + tranType + '\'' +
                ", amount=" + amount +
                ", note='" + note + '\'' +
                '}';
    }
}
