package sit.int202.accountproject.models;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

public class AccountList {
    static private ArrayList<Account> accounts = new ArrayList<>() ;

    static {
        Account account = new Account(1001, "Cash") ;
        Transaction tran = new Transaction(LocalDate.parse("2024-04-01"),"Deposit", 100.0,"Breakfast") ;
        account.addTransaction(tran);
        tran = new Transaction(LocalDate.parse("2024-04-02"),"Withdraw", 40.0,"Coffee") ;
        account.addTransaction(tran);
        accounts.add(account) ;
    }

    public ArrayList<Account> getAccounts() {
        return accounts ;
    }

    public void addAccount(Account account){
        accounts.add(account) ;
    }

    public Account find(int id){
        for(Account account: accounts){
            if(account.getId()==id){
                return account ;
            }
        }
        return null ;
    }

    public void remove(int id){
        Account account = this.find(id);
        accounts.remove(account) ;
    }

}
