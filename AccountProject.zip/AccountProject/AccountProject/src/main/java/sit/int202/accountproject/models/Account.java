package sit.int202.accountproject.models;

import java.util.ArrayList;

public class Account {
    private int id ;
    private String name ;
    private ArrayList<Transaction> transactions ;

    public Account(int id, String name) {
        this.id = id;
        this.name = name;
        this.transactions = new ArrayList<>() ;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }

    public void setTransactions(ArrayList<Transaction> transactions) {
        this.transactions = transactions;
    }

    public  void addTransaction(Transaction transaction){
        this.transactions.add(transaction) ;
    }

    public Transaction find(int id){
        for(Transaction tran: transactions){
            if(tran.getId()==id){
                return tran ;
            }
        }
        return null ;
    }

    public void remove(int id){
        Transaction tran = this.find(id) ;
        this.transactions.remove(tran) ;
    }
}
