package sit.int202.accountproject.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import sit.int202.accountproject.models.Account;
import sit.int202.accountproject.models.AccountList;
import sit.int202.accountproject.models.Transaction;

import java.io.IOException;
import java.time.LocalDate;

@WebServlet(name = "TransactionServlet", value = "/transaction")
public class TransactionServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        AccountList accountList = new AccountList();
        String accountID = request.getParameter("accountId");
        int id = Integer.parseInt(accountID);
        Account account = accountList.find(id);
        String tran = request.getParameter("tranId");
        int tranId = Integer.parseInt(tran);
        Transaction transaction = account.find(tranId);
        String action = request.getParameter("action");

        if (action.equals(null)){
            request.setAttribute("accountId", accountID);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/transaction.jsp");
            dispatcher.forward(request, response);
        } else if (account.equals("edit")) {
            request.setAttribute("transaction", transaction);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/transaction.jsp");
            dispatcher.forward(request, response);
        } else if (action.equals("delete")) {
            account.remove(tranId);
            response.sendRedirect("/transaction_list.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String strId = request.getParameter("accountId");
        int accountId = Integer.parseInt(strId);

        String strDate = request.getParameter("tranDate");
        LocalDate tranDate = LocalDate.parse(strDate);

        String tranType = request.getParameter("tranType");

        String strAmount = request.getParameter("amount");
        double amount = Double.parseDouble(strAmount);



        String note = request.getParameter("note");
        AccountList accountList = new AccountList();
        Account account = accountList.find(accountId);

        String action = request.getParameter("action");
        if (action.equals("edit")){
            String strTranId = request.getParameter("transactionId");
            int Transaction = Integer.parseInt(strTranId);
            Transaction transaction = account.find(Transaction);
            transaction.setTranDate(tranDate);
            transaction.setTranType(tranType);
            transaction.setAmount(amount);
            transaction.setNote(note);
            response.sendRedirect("/transaction-list");
        } else if (action.equals("add")) {
            Transaction transaction = new Transaction(tranDate, tranType, amount, note);
            account.addTransaction(transaction);
            response.sendRedirect("transaction-list");
        }
    }
}
