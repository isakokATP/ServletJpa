package sit.int202.accountproject.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import sit.int202.accountproject.models.Account;
import sit.int202.accountproject.models.AccountList;

import java.io.IOException;

@WebServlet(name = "TransactionListServlet", value = "/transaction-list")
public class TransactionListServlet extends HttpServlet {
    int id;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        String accountId = request.getParameter("accountId");
//        int id = Integer.parseInt(accountId);
//        AccountList accountList = new AccountList();
//        Account account = accountList.find(id);
//        if (account != null){
//            request.setAttribute("accountId", account.getId());
//            request.setAttribute("account", account.getTransactions());
//            RequestDispatcher dispatcher = request.getRequestDispatcher("/transaction_list.jsp");
//            dispatcher.forward(request, response);
//            return;
//        }
        if (id == 0){
            String strID = request.getParameter("accountId");
            id = Integer.parseInt(strID);
        }
        AccountList accountList = new AccountList();
        Account account = accountList.find(id);
        if (account != null){
            request.setAttribute("accountId", account.getId());
            request.setAttribute("account", account.getTransactions());
            RequestDispatcher dispatcher = request.getRequestDispatcher("/transaction_list.jsp");
            dispatcher.forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
