package sit.int202.accountproject.servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import sit.int202.accountproject.models.Account;
import sit.int202.accountproject.models.AccountList;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "AccountListServlet", value = "/account-list")
public class AccountListServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        AccountList accountList = new AccountList();
        request.setAttribute("accounts", accountList.getAccounts());
        RequestDispatcher requestDispatcher = request.getRequestDispatcher("/account_list.jsp");
        requestDispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
